####################################################################
# BIOS 731: Advanced Statistical Computing
#
# This file aggregates results for a particular simulation scenario
####################################################################


# Calculate bias, coverage
