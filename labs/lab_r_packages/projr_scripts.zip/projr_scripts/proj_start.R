####################################################################
# proj_start.R
#
# Creates a standardized project directory structure.
# Similar in spirit to workflowr::wflow_start().
####################################################################

proj_start <- function(name, path = here::here()) {

  project_path <- file.path(path, name)

  if (dir.exists(project_path)) {
    stop("Directory '", project_path, "' already exists.")
  }

  # create subdirectories
  for (folder in c("", "data", "source", "results", "analysis", "literature")) {
    dir.create(file.path(project_path, folder),
               recursive = TRUE, showWarnings = FALSE)
  }

  # write a minimal README
  writeLines(
    c(paste0("# ", name),
      "",
      paste0("Project created: ", Sys.Date())),
    file.path(project_path, "README.md")
  )

  # write a .gitignore
  writeLines(
    c(".Rhistory",
      ".DS_Store",
      "*.Rproj.user/"),
    file.path(project_path, ".gitignore")
  )

  # write a minimal .Rproj file
  writeLines(
    c("Version: 1.0",
      "",
      "RestoreWorkspace: No",
      "SaveWorkspace: No",
      "AlwaysSaveHistory: No"),
    file.path(project_path, paste0(name, ".Rproj"))
  )

  message("Project '", name, "' created at ", normalizePath(project_path))
  invisible(project_path)
}
