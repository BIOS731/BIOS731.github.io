####################################################################
# proj_examples.R
#
# Examples of how to use the projr helper functions:
#   proj_start(), proj_status(), proj_new_analysis()
####################################################################

# source all three functions
source("proj_start.R")
source("proj_status.R")
source("proj_new_analysis.R")

# ── proj_start() ────────────────────────────────────────────────
# Create a new project called "my_project" rooted at the current
# R project root (via here::here()). This creates subdirectories:
# data/, source/, results/, analysis/, literature/, plus a README.md,
# .Rproj file, and .gitignore.

proj_start("my_project")

# Equivalent explicit call using here::here()
proj_start("my_project", path = here::here())

# Create a project in a specific location instead
proj_start("my_project", path = "~/Desktop")

# ── proj_status() ────────────────────────────────────────────────
# Print a summary of files in each subdirectory of the project.

proj_status("my_project")

# If you are already inside the project directory, use the default
proj_status()

# ── proj_new_analysis() ──────────────────────────────────────────
# Create a new Quarto (.qmd) file inside the project's analysis/ folder.

proj_new_analysis("exploratory", project_path = "my_project")

# Create another analysis file
proj_new_analysis("model_results", project_path = "my_project")

# Check the project status again to see the new files
proj_status("my_project")
